#!/bin/bash
set -e

rm -rf build
mkdir build
cd build

# Android NDK path (adjust if needed)
export ANDROID_NDK=$PWD/../android-ndk

cmake .. -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
         -DANDROID_ABI=arm64-v8a \
         -DANDROID_PLATFORM=android-24

cmake --build .

echo "Build finished. .geode file should be in build/"
