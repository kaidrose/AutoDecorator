#include "ui.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;

class AutoDecoratorPopup : public geode::Popup<> {
protected:
    bool setup() override {
        this->setTitle("AutoDecorator");

        auto menu = CCMenu::create();
        menu->setPosition(CCPoint { 0, 0 });

        addUIButton("Apply Style");
        addUIButton("Randomize");
        addUIButton("Reset");

        this->m_mainLayer->addChild(menu);
        return true;
    }

public:
    static AutoDecoratorPopup* create() {
        auto ret = new AutoDecoratorPopup();
        if (ret && ret->initAnchored(240.f, 160.f)) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

void createModMenu() {
    log::info("Creating AutoDecorator menu...");
}

void addUIButton(const std::string& name) {
    log::info("Adding button: {}", name);
}
