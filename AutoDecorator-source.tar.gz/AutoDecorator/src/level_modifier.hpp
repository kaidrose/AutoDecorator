#pragma once
#include <string>

void modifyLevelObjects(const std::string& style);
