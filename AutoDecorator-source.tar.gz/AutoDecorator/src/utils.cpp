#include "utils.hpp"
#include <cstdlib>
#include <ctime>
#include <algorithm>

int randomInt(int min, int max) {
    static bool seeded = false;
    if (!seeded) {
        std::srand(static_cast<unsigned>(std::time(nullptr)));
        seeded = true;
    }
    return min + std::rand() % ((max + 1) - min);
}

std::string capitalize(const std::string& str) {
    std::string s = str;
    if (!s.empty()) {
        s[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
    }
    return s;
}
