#pragma once
#include <string>

int randomInt(int min, int max);
std::string capitalize(const std::string& str);
