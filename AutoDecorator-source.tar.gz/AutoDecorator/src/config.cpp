#include "config.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;

static std::string savedStyle = "Classic";

void saveConfig() {
    auto* mod = Mod::get();
    mod->setSavedValue("savedStyle", savedStyle);
    log::info("Saving AutoDecorator config: style={}", savedStyle);
}

void loadConfig() {
    auto* mod = Mod::get();
    savedStyle = mod->getSavedValue<std::string>("savedStyle", "Classic");
    log::info("Loading AutoDecorator config: style={}", savedStyle);
}

std::string getSavedStyle() {
    return savedStyle;
}

void setSavedStyle(const std::string& style) {
    savedStyle = style;
}
