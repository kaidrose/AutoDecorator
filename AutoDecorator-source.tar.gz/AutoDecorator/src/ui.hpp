#pragma once
#include <string>

void createModMenu();
void addUIButton(const std::string& name);
