#include "level_modifier.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;

void modifyLevelObjects(const std::string& style) {
    log::info("Modifying level objects with style: {}", style);

    auto* lel = LevelEditorLayer::get();
    if (!lel) {
        log::warn("No active editor layer found.");
        return;
    }

    auto* objects = lel->m_objects;
    if (!objects) return;

    for (int i = 0; i < objects->count(); i++) {
        auto* obj = static_cast<GameObject*>(objects->objectAtIndex(i));
        if (!obj) continue;

        if (style == "Neon") {
            obj->setColor({ 0, 255, 200 });
        } else if (style == "Dark") {
            obj->setColor({ 30, 30, 30 });
        } else if (style == "Classic") {
            obj->setColor({ 255, 200, 100 });
        } else if (style == "Retro") {
            obj->setColor({ 200, 100, 50 });
        } else if (style == "Glitch") {
            obj->setColor({ 255, 0, 128 });
        }
    }

    log::info("Applied color modifications for style: {}", style);
}
