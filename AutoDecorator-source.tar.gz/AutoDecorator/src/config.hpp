#pragma once
#include <string>

void saveConfig();
void loadConfig();
std::string getSavedStyle();
void setSavedStyle(const std::string& style);
