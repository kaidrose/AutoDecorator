#pragma once
#include <string>

std::string getRandomStyle();
void applyStyle(const std::string& style);
