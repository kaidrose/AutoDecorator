#include <Geode/Geode.hpp>
#include "decorator.hpp"
#include "utils.hpp"
#include <vector>

using namespace geode::prelude;

static std::vector<std::string> styles = {
    "Classic",
    "Neon",
    "Dark",
    "Retro",
    "Glitch"
};

std::string getRandomStyle() {
    int index = randomInt(0, static_cast<int>(styles.size()) - 1);
    return capitalize(styles[index]);
}

void applyStyle(const std::string& style) {
    log::info("Applying decorator style: {}", style);

    if (style == "Classic") {
        log::info("Classic: warm tones, standard lighting");
    } else if (style == "Neon") {
        log::info("Neon: bright neon colors, glow effects");
    } else if (style == "Dark") {
        log::info("Dark: dark background, high contrast objects");
    } else if (style == "Retro") {
        log::info("Retro: pixel art palette, old-school feel");
    } else if (style == "Glitch") {
        log::info("Glitch: RGB split, corrupted look");
    }
}
