#include <Geode/Geode.hpp>
#include "decorator.hpp"
#include "level_modifier.hpp"
#include "ui.hpp"
#include "config.hpp"

using namespace geode::prelude;

class AutoDecoratorMod : public Mod {
public:
    void onLoad() override {
        log::info("AutoDecorator loaded!");
        loadConfig();
        createModMenu();

        auto style = getRandomStyle();
        applyStyle(style);
        modifyLevelObjects(style);
        log::info("Applied style: {}", style);
    }

    void onUnload() override {
        log::info("AutoDecorator unloaded!");
        saveConfig();
    }
};

GEODE_REGISTER_MOD(AutoDecoratorMod)
