# AutoDecorator

A [Geode](https://geode-sdk.org) mod for Geometry Dash 2.2 that automatically decorates levels with randomized visual styles.

## Styles
- **Classic** — warm tones, standard lighting
- **Neon** — vivid neon colors with glow effects
- **Dark** — deep dark backgrounds, high contrast objects
- **Retro** — pixel art palette, old-school feel
- **Glitch** — RGB split, corrupted visual distortion

## Requirements
- Geometry Dash 2.2081
- Geode Mod Loader ≥ 5.4.1

## Install (pre-built)
1. Download `AutoDecorator.geode` from the [Releases](../../releases) page
2. Drop it into your Geode mods folder
3. Launch Geometry Dash

## Build from source
Push to GitHub — the included Actions workflow builds the Android `.geode` automatically.

To trigger a release build, create a version tag:
```bash
git tag v1.0.0
git push origin v1.0.0
```
The workflow compiles the mod and attaches the `.geode` file to a GitHub Release.

## Setup
Before using, edit `mod.json` and replace:
- `"yourname.autodecorator"` → your Geode username + mod name (e.g. `"alice.autodecorator"`)
- `"YourName"` → your name
